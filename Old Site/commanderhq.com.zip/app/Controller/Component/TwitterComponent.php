<?php

App::uses('Component', 'Controller');


Class TwitterComponent extends Component
{
	
}