<?php


App::uses('AppController', 'Controller');

class PaymentsController extends AppController 
{

	public $scaffold = 'admin';

	public $uses = array();

	public function index() {
		
	}
}
