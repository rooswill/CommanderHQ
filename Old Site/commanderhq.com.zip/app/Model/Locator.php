<?php
    App::uses('AppModel', 'Model');

    class Locator extends AppModel 
    {

    }   

}